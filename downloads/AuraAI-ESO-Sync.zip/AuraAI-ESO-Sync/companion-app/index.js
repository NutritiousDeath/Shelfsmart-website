// index.js — EsoDiscordSync companion app
//
// Watches the ESO addon's SavedVariables file and, every time it changes
// (which only happens on /reloadui, zone change, or logout — see the addon's
// own comments), reads the current roster for every guild branch found in
// it and POSTs each one separately to the AuraAI roster sync endpoint.
//
// Stays running continuously in the background. Ctrl+C to stop.

const fs = require('fs');
const chokidar = require('chokidar');
const { loadOrCreateConfig } = require('./config');
const { parseLuaSavedVariables } = require('./lua-table-parser');

let config;

async function syncFromFile() {
  if (!fs.existsSync(config.savedVariablesPath)) {
    console.log(`[${nowStamp()}] Waiting for SavedVariables file to be created — run /esosync then /reloadui in-game.`);
    return;
  }

  let parsed;
  try {
    const raw = fs.readFileSync(config.savedVariablesPath, 'utf8');
    parsed = parseLuaSavedVariables(raw, 'EsoDiscordSyncSV');
  } catch (err) {
    console.error(`[${nowStamp()}] Could not parse SavedVariables file:`, err.message);
    return;
  }

  const guilds = parsed?.guilds;
  if (!guilds || typeof guilds !== 'object' || Object.keys(guilds).length === 0) {
    console.log(`[${nowStamp()}] No guild data found yet — run /esosync then /reloadui in-game.`);
    return;
  }

  for (const [guildName, members] of Object.entries(guilds)) {
    if (!Array.isArray(members) || members.length === 0) continue;

    const roster = members
      .filter(m => m && m.accountName)
      .map(m => ({ accountName: m.accountName, rank: m.rank || '' }));

    try {
      const res = await fetch(`${config.railwayUrl}/api/eso-roster-sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: config.syncToken,
          discordServerId: config.discordServerId,
          esoGuildName: guildName,
          roster,
        }),
      });
      const result = await res.json();
      if (!res.ok) {
        console.error(`[${nowStamp()}] "${guildName}" sync failed:`, result.error || `HTTP ${res.status}`);
      } else {
        console.log(`[${nowStamp()}] "${guildName}" synced — ${result.rosterCount} members, ${result.left} left. Role changes: ${result.roleSync.status === 'queued' ? 'processing in background (check Discord shortly for large rosters)' : result.roleSync.reason || 'none needed'}.`);
      }
    } catch (err) {
      console.error(`[${nowStamp()}] "${guildName}" sync request failed:`, err.message);
    }
  }
}

function nowStamp() {
  return new Date().toLocaleTimeString();
}

async function main() {
  config = await loadOrCreateConfig();

  console.log('EsoDiscordSync companion app running.');
  console.log(`Watching: ${config.savedVariablesPath}`);
  console.log('Leave this window open while you play — it re-syncs automatically on every /reloadui.');
  console.log('Press Ctrl+C to stop.');
  console.log('');

  // Initial sync in case the file already has data from a previous session
  await syncFromFile();

  const watcher = chokidar.watch(config.savedVariablesPath, {
    // ESO writes the file in one shot on reload/logout, but awaitWriteFinish
    // guards against reading a partially-written file just in case.
    awaitWriteFinish: { stabilityThreshold: 1000, pollInterval: 200 },
    ignoreInitial: true,
  });

  watcher.on('add', syncFromFile);
  watcher.on('change', syncFromFile);
  watcher.on('error', err => console.error(`[${nowStamp()}] Watcher error:`, err.message));
}

main().catch(err => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});
