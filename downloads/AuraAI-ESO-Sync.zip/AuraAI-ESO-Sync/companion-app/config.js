// config.js
//
// On first run, asks for the two things this companion app needs (your
// Discord server ID + this server's ESO sync token, both from the AuraAI
// dashboard's ESO Guild Sync tab) and saves them to config.json next to
// this script. Every run after that just loads config.json silently.
//
// To reconfigure later (new server, new token after regenerating), delete
// config.json and run the app again — it'll re-ask.

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const os = require('os');

const CONFIG_PATH = path.join(__dirname, 'config.json');

function defaultSavedVariablesPath() {
  return path.join(os.homedir(), 'Documents', 'Elder Scrolls Online', 'live', 'SavedVariables', 'EsoDiscordSync.lua');
}

function ask(rl, question) {
  return new Promise(resolve => rl.question(question, answer => resolve(answer.trim())));
}

async function loadOrCreateConfig() {
  if (fs.existsSync(CONFIG_PATH)) {
    return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  }

  console.log('');
  console.log('=== EsoDiscordSync companion app — first-time setup ===');
  console.log('');
  console.log('Get these two values from the AuraAI dashboard: ESO Guild Sync tab.');
  console.log('');

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

  const discordServerId = await ask(rl, 'Discord Server ID: ');
  const syncToken = await ask(rl, 'Sync Token: ');

  const defaultPath = defaultSavedVariablesPath();
  console.log('');
  console.log(`Default SavedVariables file location:`);
  console.log(`  ${defaultPath}`);
  const customPath = await ask(rl, 'Press Enter to use this, or paste a different path: ');

  rl.close();

  const config = {
    discordServerId,
    syncToken,
    savedVariablesPath: customPath || defaultPath,
    railwayUrl: 'https://web-production-01b81.up.railway.app',
  };

  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
  console.log('');
  console.log(`Saved to ${CONFIG_PATH} — won't ask again unless you delete that file.`);
  console.log('');

  return config;
}

module.exports = { loadOrCreateConfig, CONFIG_PATH };
