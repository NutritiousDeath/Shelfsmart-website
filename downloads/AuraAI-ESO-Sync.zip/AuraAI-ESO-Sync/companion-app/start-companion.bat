@echo off
REM start-companion.bat
REM
REM Launches the EsoDiscordSync companion app and automatically restarts it
REM if it ever crashes or exits unexpectedly. Meant to be run via a shortcut
REM in the Windows Startup folder, with that shortcut's "Run" property set
REM to "Minimized" so it launches out of the way instead of popping up a
REM full window every time you log in.

cd /d "%~dp0"

:loop
echo [EsoDiscordSync] Starting companion app...
node index.js

echo.
echo [EsoDiscordSync] Process stopped - restarting in 5 seconds... (close this window to stop for good)
timeout /t 5 /nobreak >nul
goto loop
