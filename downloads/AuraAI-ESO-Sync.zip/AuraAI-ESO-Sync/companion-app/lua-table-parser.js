// lua-table-parser.js
//
// Parses the Lua table literal ESO writes to SavedVariables files. This is
// NOT a general Lua interpreter — it's a small tokenizer + recursive-descent
// parser scoped exactly to the subset of syntax ESO's serializer produces:
// nested tables, ["key"]/[n] = value pairs, strings, numbers, booleans, nil,
// and trailing commas. Since we control the addon that WRITES this file
// (EsoDiscordSync.lua), we know exactly what shape to expect — this parser
// doesn't need to handle arbitrary Lua code, only ESO's own serialization.

function parseLuaSavedVariables(source, varName) {
  const markerIndex = source.indexOf(varName);
  if (markerIndex === -1) throw new Error(`Could not find "${varName}" in SavedVariables file`);

  let eqIndex = source.indexOf('=', markerIndex);
  if (eqIndex === -1) throw new Error(`Could not find "=" after "${varName}"`);

  const state = { pos: eqIndex + 1 };
  return parseValue(source, state);
}

function skipWhitespaceAndComments(str, pos) {
  let i = pos;
  while (i < str.length) {
    if (/\s/.test(str[i])) { i++; continue; }
    if (str[i] === '-' && str[i + 1] === '-') {
      while (i < str.length && str[i] !== '\n') i++;
      continue;
    }
    break;
  }
  return i;
}

function parseValue(str, state) {
  state.pos = skipWhitespaceAndComments(str, state.pos);
  const c = str[state.pos];

  if (c === '{') return parseTable(str, state);
  if (c === '"' || c === "'") return parseString(str, state);
  if (str.startsWith('true', state.pos)) { state.pos += 4; return true; }
  if (str.startsWith('false', state.pos)) { state.pos += 5; return false; }
  if (str.startsWith('nil', state.pos)) { state.pos += 3; return null; }
  return parseNumber(str, state);
}

function parseString(str, state) {
  const quote = str[state.pos];
  state.pos++;
  let out = '';
  while (str[state.pos] !== quote) {
    if (state.pos >= str.length) throw new Error('Unterminated string in SavedVariables file');
    if (str[state.pos] === '\\') {
      const next = str[state.pos + 1];
      const escapes = { n: '\n', t: '\t', '"': '"', "'": "'", '\\': '\\' };
      out += escapes[next] !== undefined ? escapes[next] : next;
      state.pos += 2;
    } else {
      out += str[state.pos];
      state.pos++;
    }
  }
  state.pos++; // closing quote
  return out;
}

function parseNumber(str, state) {
  const match = /^-?\d+(\.\d+)?/.exec(str.slice(state.pos));
  if (!match) {
    throw new Error(`Unexpected token at position ${state.pos}: "${str.slice(state.pos, state.pos + 20)}"`);
  }
  state.pos += match[0].length;
  return parseFloat(match[0]);
}

function parseTable(str, state) {
  state.pos++; // consume {
  const obj = {};
  let hasStringKey = false;
  let maxNumericKey = 0;
  let numEntries = 0;

  while (true) {
    state.pos = skipWhitespaceAndComments(str, state.pos);
    if (str[state.pos] === '}') { state.pos++; break; }
    if (state.pos >= str.length) throw new Error('Unterminated table in SavedVariables file');

    let key;
    if (str[state.pos] === '[') {
      state.pos++;
      state.pos = skipWhitespaceAndComments(str, state.pos);
      if (str[state.pos] === '"' || str[state.pos] === "'") {
        key = parseString(str, state);
        hasStringKey = true;
      } else {
        const numMatch = /^-?\d+/.exec(str.slice(state.pos));
        key = parseInt(numMatch[0], 10);
        state.pos += numMatch[0].length;
        maxNumericKey = Math.max(maxNumericKey, key);
      }
      state.pos = skipWhitespaceAndComments(str, state.pos);
      if (str[state.pos] !== ']') throw new Error(`Expected "]" at position ${state.pos}`);
      state.pos++;
    } else {
      const idMatch = /^[A-Za-z_][A-Za-z0-9_]*/.exec(str.slice(state.pos));
      if (!idMatch) throw new Error(`Expected table key at position ${state.pos}`);
      key = idMatch[0];
      state.pos += idMatch[0].length;
      hasStringKey = true;
    }

    state.pos = skipWhitespaceAndComments(str, state.pos);
    if (str[state.pos] !== '=') throw new Error(`Expected "=" at position ${state.pos}`);
    state.pos++;

    obj[key] = parseValue(str, state);
    numEntries++;

    state.pos = skipWhitespaceAndComments(str, state.pos);
    if (str[state.pos] === ',' || str[state.pos] === ';') state.pos++;
  }

  // Purely-numeric-keyed tables (1, 2, 3...) are Lua's arrays — convert to
  // a real JS array so downstream code can just use .map()/.forEach().
  if (!hasStringKey && numEntries > 0 && maxNumericKey === numEntries) {
    const arr = [];
    for (let n = 1; n <= maxNumericKey; n++) arr.push(obj[n]);
    return arr;
  }

  return obj;
}

module.exports = { parseLuaSavedVariables };
