AURAAI ESO GUILD SYNC — SETUP
================================

This download has two separate pieces that go to two separate places.

────────────────────────────────────────
1. THE ADDON  (addon/EsoDiscordSync/)
────────────────────────────────────────
Copy the whole "EsoDiscordSync" folder into your ESO AddOns folder:

  Documents\Elder Scrolls Online\live\AddOns\

Then open EsoDiscordSync.txt in that folder and check the "## APIVersion"
line matches your current game version — copy the exact number from any
other working addon's manifest if you're not sure. If this number is wrong,
the addon will just silently fail to appear in the Addon Manager.

Launch ESO, confirm EsoDiscordSync shows up (checked) in the in-game
Addon Manager.

────────────────────────────────────────
2. THE COMPANION APP  (companion-app/)
────────────────────────────────────────
Copy the whole "companion-app" folder anywhere on your PC — your Desktop
is fine. This does NOT go in the ESO folder.

Requires Node.js (18 or newer) installed on your PC.

Open a terminal in that folder and run:

  npm install
  npm start

First run will ask for your Discord Server ID and Sync Token — both are
in the AuraAI dashboard, under the ESO Guild Sync tab.

To have it start automatically every time you log into Windows:
see start-companion.bat, and the setup guide on this page.

────────────────────────────────────────
IN-GAME USAGE
────────────────────────────────────────
Type /esosync in chat, then /reloadui. Do this any time you want to force
a fresh sync — it also happens automatically on every reload, zone
change, and login.

────────────────────────────────────────
LEGAL
────────────────────────────────────────
This Add-on is not created by, affiliated with or sponsored by ZeniMax
Media Inc. or its affiliates. The Elder Scrolls® and related logos are
registered trademarks or trademarks of ZeniMax Media Inc. in the United
States and/or other countries. All rights reserved.
