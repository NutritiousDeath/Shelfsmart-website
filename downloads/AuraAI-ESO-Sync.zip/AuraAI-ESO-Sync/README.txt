AURAAI ESO GUILD SYNC — SETUP
================================

This download has two separate pieces that go to two separate places.

────────────────────────────────────────
1. THE ADDON  (addon/EsoDiscordSync/)
────────────────────────────────────────
Copy the whole "EsoDiscordSync" folder into your ESO AddOns folder:

  Documents\Elder Scrolls Online\live\AddOns\

Launch ESO, confirm EsoDiscordSync shows up checked in the in-game
Addon Manager. It ships pre-configured for the current game version —
nothing to edit.

If it's ever flagged "out of date" after a big ESO update, that alone
doesn't mean it stopped working. Check the AuraAI dashboard's ESO Sync
Files page for an updated download if you run into trouble.

────────────────────────────────────────
2. THE COMPANION APP  (companion-app/)
────────────────────────────────────────
Copy the whole "companion-app" folder anywhere on your PC — your Desktop
is fine. This does NOT go in the ESO folder.

Requires Node.js (18 or newer) installed on your PC.

Open a terminal in that folder and run:

  npm install
  npm start

First run will ask for your Discord Server ID and Sync Token — both are
in the AuraAI dashboard, under the ESO Guild Sync tab.

To have it start automatically every time you log into Windows:
see start-companion.bat, and the setup guide on this page.

────────────────────────────────────────
IN-GAME USAGE
────────────────────────────────────────
Type /esosync in chat, then /reloadui. Do this any time you want to force
a fresh sync — it also happens automatically on every reload, zone
change, and login.

────────────────────────────────────────
LEGAL
────────────────────────────────────────
This Add-on is not created by, affiliated with or sponsored by ZeniMax
Media Inc. or its affiliates. The Elder Scrolls® and related logos are
registered trademarks or trademarks of ZeniMax Media Inc. in the United
States and/or other countries. All rights reserved.
