-- EsoDiscordSync.lua
--
-- Loops every guild the logged-in account belongs to (up to ESO's 5-guild
-- cap) and writes each guild's full member roster + rank into
-- SavedVariables. A companion app running outside the game (see the
-- separate Node.js companion app) watches that file on disk and POSTs each
-- guild's roster to the AuraAI Railway backend, which syncs Discord roles.
--
-- IMPORTANT LIMITATION: ESO only writes SavedVariables to disk on a zone
-- change, /reloadui, or logout — never live/instantly. So after running
-- /esosync in chat, you must /reloadui before the companion app can see
-- the update. This addon also re-syncs automatically on every reload and
-- zone change, so in normal play it stays fresh without any manual step.
--
-- Roster read access only requires guild MEMBERSHIP, not officer/GM rank —
-- this works identically regardless of your rank in any given branch.

EsoDiscordSync = {}
local addon = EsoDiscordSync
addon.name = "EsoDiscordSync"

-- Every ESO guild starts with these 4 default rank names. If a guild
-- leader never renamed a rank, GetGuildRankCustomName() returns an empty
-- string instead of the name — so this fallback fills in the standard
-- default names rather than leaving the rank blank for those members.
-- Ranks 5-10 have no documented default name until a guild customizes
-- them, so those fall back to "Rank N" instead.
local DEFAULT_RANK_NAMES = {
  [1] = "Guildmaster",
  [2] = "Officer",
  [3] = "Member",
  [4] = "Recruit",
}

-- Pulls every guild's full roster into a table keyed by exact in-game guild
-- name — this name must match exactly (case doesn't matter) whatever guild
-- name was typed into the AuraAI dashboard's "+ Add Guild" field.
function addon.SyncAllGuilds()
  local guildsData = {}
  local numGuilds = GetNumGuilds()

  for i = 1, numGuilds do
    local guildId = GetGuildId(i)
    local guildName = GetGuildName(guildId)
    if guildName and guildName ~= "" then
      local members = {}
      local numMembers = GetNumGuildMembers(guildId)
      for j = 1, numMembers do
        local accountName, note, rankIndex = GetGuildMemberInfo(guildId, j)
        local rankName = GetGuildRankCustomName(guildId, rankIndex)
        if not rankName or rankName == "" then
          rankName = DEFAULT_RANK_NAMES[rankIndex] or ("Rank " .. tostring(rankIndex))
        end
        if accountName and accountName ~= "" then
          table.insert(members, { accountName = accountName, rank = rankName })
        end
      end
      guildsData[guildName] = members
    end
  end

  EsoDiscordSyncSV.guilds = guildsData
  EsoDiscordSyncSV.lastSync = GetTimeStamp()

  return numGuilds
end

function addon.OnAddOnLoaded(event, addOnName)
  if addOnName ~= addon.name then return end
  EVENT_MANAGER:UnregisterForEvent(addon.name, EVENT_ADD_ON_LOADED)

  EsoDiscordSyncSV = EsoDiscordSyncSV or {}

  -- Re-sync automatically whenever the player fully loads into the world —
  -- covers reload, zone change, and login without needing a manual command.
  EVENT_MANAGER:RegisterForEvent(addon.name, EVENT_PLAYER_ACTIVATED, function()
    addon.SyncAllGuilds()
  end)
end

EVENT_MANAGER:RegisterForEvent(addon.name, EVENT_ADD_ON_LOADED, addon.OnAddOnLoaded)

-- Manual trigger for testing. Only updates the in-memory table — still
-- needs a /reloadui afterward before the companion app sees the change on
-- disk (see the disk-write limitation noted above).
SLASH_COMMANDS["/esosync"] = function()
  local numGuilds = addon.SyncAllGuilds()
  d("[EsoDiscordSync] Synced " .. tostring(numGuilds) .. " guild(s) to memory. Run /reloadui to write it to disk.")
end
